=== Yuuta WordPress Theme ===
Contributers: Felix Dorner
Donate link: http://drnr.co
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: black, white, dark, light, fluid-layout, responsive-layout, custom-colors, custom-menu, editor-style, featured-images, full-width-template, post-formats, sticky-post, theme-options, threaded-comments, translation-ready, photoblogging
Requires at least: 3.8
Tested up to: 4.2

Yuuta is a clean and free WordPress theme designed to serve as a visual diary. Due to support of all post formats you can create a pretty diversified blog.

== Description ==

Yuuta is a clean and free WordPress theme designed to serve as a visual diary. Due to support of all post formats you can create a pretty diversified blog.

== Installation ==
1. Sign into your WordPress dashboard, go to Appearance > Themes, and click Add New.
2. Click Upload.
3. Click Choose File and select the theme zip file within the 'all-files'-package you downloaded.
4. Click Install Now.
5. After WordPress installs the theme, click Activate.
6. You've successfully installed your new theme!

== Frequently Asked Questions ==

= I need more help! What should I do? =

Ping me on Twitter (@felixdorner) and I'll try to help you.

== Change Log ==

= 1.3 =
* Better font loading
* Added licenses for fonts

= 1.2 =
* Fixed archives template

= 1.1 =
* Changed footer/pagination/comments color
* Removed pre-loader

= 1.0 =
* Initial release